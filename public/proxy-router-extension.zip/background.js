// Proxy Router Chrome Extension - Background Script
class ProxyRouterExtension {
  constructor() {
    this.apiBaseUrl = 'https://api.theholylabs.com'; // Your backend URL
    this.clientId = this.generateClientId();
    this.isConnected = false;
    this.isProxyEnabled = false;
    this.currentHostId = null;
    this.heartbeatInterval = null;
    this.proxyConfig = null;
    
    this.init();
  }

  generateClientId() {
    // Generate a unique client ID for this extension instance
    return 'chrome-ext-' + Math.random().toString(36).substr(2, 9) + '-' + Date.now();
  }

  async init() {
    console.log('Proxy Router Extension initialized');
    
    // Load saved settings
    await this.loadSettings();
    
    // Register with the proxy server
    await this.registerWithServer();
    
    // Set up event listeners
    this.setupEventListeners();
    
    // Start heartbeat if connected
    if (this.isConnected) {
      this.startHeartbeat();
    }
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.sync.get([
        'apiBaseUrl',
        'isProxyEnabled',
        'proxyConfig'
      ]);
      
      this.apiBaseUrl = result.apiBaseUrl || this.apiBaseUrl;
      this.isProxyEnabled = result.isProxyEnabled || false;
      this.proxyConfig = result.proxyConfig || null;
      
      console.log('Settings loaded:', { apiBaseUrl: this.apiBaseUrl, isProxyEnabled: this.isProxyEnabled });
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  async saveSettings() {
    try {
      await chrome.storage.sync.set({
        apiBaseUrl: this.apiBaseUrl,
        isProxyEnabled: this.isProxyEnabled,
        proxyConfig: this.proxyConfig
      });
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  }

  async registerWithServer() {
    try {
      const response = await fetch(`${this.apiBaseUrl}/api/proxy/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: this.clientId,
          is_router: false,
          can_proxy: false, // Chrome extension can't act as proxy server
          online: true
        })
      });

      const result = await response.json();
      
      if (result.success) {
        this.isConnected = true;
        this.currentHostId = result.current_host_id;
        console.log('Successfully registered with proxy server:', result);
        
        // Update badge
        chrome.action.setBadgeText({ text: 'ON' });
        chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
        
        // Notify popup
        this.notifyPopup('connected', result);
      } else {
        console.error('Failed to register with proxy server:', result.error);
        this.isConnected = false;
        this.notifyPopup('error', result.error);
      }
    } catch (error) {
      console.error('Error registering with server:', error);
      this.isConnected = false;
      this.notifyPopup('error', error.message);
    }
  }

  async sendHeartbeat() {
    if (!this.isConnected) return;

    try {
      const response = await fetch(`${this.apiBaseUrl}/api/proxy/heartbeat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: this.clientId
        })
      });

      const result = await response.json();
      
      if (result.success) {
        this.currentHostId = result.current_host_id;
        console.log('Heartbeat sent successfully');
      } else {
        console.error('Heartbeat failed:', result.error);
        this.isConnected = false;
        this.stopHeartbeat();
      }
    } catch (error) {
      console.error('Error sending heartbeat:', error);
      this.isConnected = false;
      this.stopHeartbeat();
    }
  }

  startHeartbeat() {
    if (this.heartbeatInterval) return;
    
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, 30000); // Send heartbeat every 30 seconds
    
    console.log('Heartbeat started');
  }

  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
      console.log('Heartbeat stopped');
    }
  }

  async getServerStatus() {
    try {
      const response = await fetch(`${this.apiBaseUrl}/api/proxy/status`);
      const result = await response.json();
      
      if (result.success) {
        return result.status;
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Error getting server status:', error);
      throw error;
    }
  }

  async createProxyRoute(url, method = 'GET', headers = {}, body = null) {
    try {
      const response = await fetch(`${this.apiBaseUrl}/api/proxy/route`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          route_type: 'http_fetch',
          url: url,
          method: method,
          headers: headers,
          body: body
        })
      });

      const result = await response.json();
      
      if (result.success) {
        console.log('Proxy route created:', result.route);
        return result.route;
      } else {
        throw new Error(result.error);
      }
    } catch (error) {
      console.error('Error creating proxy route:', error);
      throw error;
    }
  }

  async toggleProxy() {
    this.isProxyEnabled = !this.isProxyEnabled;
    await this.saveSettings();
    
    if (this.isProxyEnabled) {
      await this.enableProxy();
    } else {
      await this.disableProxy();
    }
    
    // Notify popup of state change
    this.notifyPopup('proxyToggled', { enabled: this.isProxyEnabled });
  }

  async enableProxy() {
    if (!this.isConnected) {
      throw new Error('Not connected to proxy server');
    }

    try {
      // Get current proxy configuration from server
      const status = await this.getServerStatus();
      
      if (!status.current_exit_id) {
        throw new Error('No available proxy hosts');
      }

      // For now, we'll use a simple HTTP proxy approach
      // In a real implementation, you'd configure Chrome's proxy settings
      console.log('Proxy enabled - would configure Chrome proxy settings here');
      
      // Update badge
      chrome.action.setBadgeText({ text: 'PROXY' });
      chrome.action.setBadgeBackgroundColor({ color: '#FF9800' });
      
    } catch (error) {
      console.error('Error enabling proxy:', error);
      this.isProxyEnabled = false;
      throw error;
    }
  }

  async disableProxy() {
    try {
      // Disable Chrome proxy settings
      console.log('Proxy disabled - would reset Chrome proxy settings here');
      
      // Update badge
      chrome.action.setBadgeText({ text: 'ON' });
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
      
    } catch (error) {
      console.error('Error disabling proxy:', error);
    }
  }

  setupEventListeners() {
    // Listen for messages from popup and content scripts
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse);
      return true; // Keep message channel open for async response
    });

    // Listen for extension installation/update
    chrome.runtime.onInstalled.addListener((details) => {
      console.log('Extension installed/updated:', details);
      this.init();
    });

    // Listen for tab updates to potentially inject proxy logic
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === 'complete' && this.isProxyEnabled) {
        this.handleTabUpdate(tabId, tab);
      }
    });
  }

  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.action) {
        case 'getStatus':
          const status = await this.getServerStatus();
          sendResponse({ success: true, status: status });
          break;

        case 'toggleProxy':
          await this.toggleProxy();
          sendResponse({ success: true, enabled: this.isProxyEnabled });
          break;

        case 'getSettings':
          sendResponse({
            success: true,
            settings: {
              apiBaseUrl: this.apiBaseUrl,
              isProxyEnabled: this.isProxyEnabled,
              isConnected: this.isConnected,
              clientId: this.clientId
            }
          });
          break;

        case 'updateSettings':
          if (request.settings.apiBaseUrl) {
            this.apiBaseUrl = request.settings.apiBaseUrl;
            await this.saveSettings();
            // Re-register with new server
            await this.registerWithServer();
          }
          sendResponse({ success: true });
          break;

        case 'createRoute':
          const route = await this.createProxyRoute(
            request.url,
            request.method,
            request.headers,
            request.body
          );
          sendResponse({ success: true, route: route });
          break;

        default:
          sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      console.error('Error handling message:', error);
      sendResponse({ success: false, error: error.message });
    }
  }

  async handleTabUpdate(tabId, tab) {
    // Inject proxy logic into the tab if needed
    if (this.isProxyEnabled && tab.url && !tab.url.startsWith('chrome://')) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          files: ['injected.js']
        });
      } catch (error) {
        console.error('Error injecting script:', error);
      }
    }
  }

  notifyPopup(type, data) {
    // Send message to popup if it's open
    chrome.runtime.sendMessage({
      type: 'notification',
      notificationType: type,
      data: data
    }).catch(() => {
      // Popup might not be open, ignore error
    });
  }
}

// Initialize the extension
const proxyRouter = new ProxyRouterExtension();
