// Proxy Router Extension - Popup Script
class PopupController {
  constructor() {
    this.elements = {};
    this.isLoading = false;
    
    this.init();
  }

  init() {
    this.cacheElements();
    this.bindEvents();
    this.loadInitialData();
  }

  cacheElements() {
    this.elements = {
      statusIndicator: document.getElementById('statusIndicator'),
      statusDot: document.getElementById('statusDot'),
      statusText: document.getElementById('statusText'),
      serverStatus: document.getElementById('serverStatus'),
      clientId: document.getElementById('clientId'),
      currentHost: document.getElementById('currentHost'),
      proxyToggle: document.getElementById('proxyToggle'),
      proxyInfo: document.getElementById('proxyInfo'),
      totalDevices: document.getElementById('totalDevices'),
      onlineDevices: document.getElementById('onlineDevices'),
      proxyDevices: document.getElementById('proxyDevices'),
      apiUrl: document.getElementById('apiUrl'),
      saveSettings: document.getElementById('saveSettings'),
      refreshStatus: document.getElementById('refreshStatus'),
      reconnect: document.getElementById('reconnect'),
      loadingOverlay: document.getElementById('loadingOverlay'),
      errorMessage: document.getElementById('errorMessage'),
      errorText: document.getElementById('errorText'),
      closeError: document.getElementById('closeError')
    };
  }

  bindEvents() {
    // Proxy toggle
    this.elements.proxyToggle.addEventListener('change', () => {
      this.toggleProxy();
    });

    // Settings
    this.elements.saveSettings.addEventListener('click', () => {
      this.saveSettings();
    });

    // Actions
    this.elements.refreshStatus.addEventListener('click', () => {
      this.refreshStatus();
    });

    this.elements.reconnect.addEventListener('click', () => {
      this.reconnect();
    });

    // Error close
    this.elements.closeError.addEventListener('click', () => {
      this.hideError();
    });

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message);
    });
  }

  async loadInitialData() {
    this.showLoading();
    
    try {
      // Get current settings
      const settingsResponse = await this.sendMessage({ action: 'getSettings' });
      if (settingsResponse.success) {
        this.updateSettingsDisplay(settingsResponse.settings);
      }

      // Get server status
      await this.refreshStatus();
      
    } catch (error) {
      this.showError('Failed to load initial data: ' + error.message);
    } finally {
      this.hideLoading();
    }
  }

  async sendMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: chrome.runtime.lastError.message });
        } else {
          resolve(response || { success: false, error: 'No response' });
        }
      });
    });
  }

  updateSettingsDisplay(settings) {
    this.elements.apiUrl.value = settings.apiBaseUrl || '';
    this.elements.clientId.textContent = settings.clientId || 'Unknown';
    
    // Update connection status
    this.updateConnectionStatus(settings.isConnected, settings.isProxyEnabled);
  }

  updateConnectionStatus(isConnected, isProxyEnabled) {
    if (isConnected) {
      this.elements.statusDot.className = 'status-dot connected';
      this.elements.statusText.textContent = 'Connected';
      this.elements.proxyToggle.disabled = false;
      
      if (isProxyEnabled) {
        this.elements.statusDot.className = 'status-dot proxy';
        this.elements.statusText.textContent = 'Proxy Active';
        this.elements.proxyToggle.checked = true;
        this.elements.proxyInfo.style.display = 'block';
      } else {
        this.elements.proxyToggle.checked = false;
        this.elements.proxyInfo.style.display = 'none';
      }
    } else {
      this.elements.statusDot.className = 'status-dot';
      this.elements.statusText.textContent = 'Disconnected';
      this.elements.proxyToggle.disabled = true;
      this.elements.proxyToggle.checked = false;
      this.elements.proxyInfo.style.display = 'none';
    }
  }

  async refreshStatus() {
    try {
      const response = await this.sendMessage({ action: 'getStatus' });
      
      if (response.success) {
        this.updateStatusDisplay(response.status);
      } else {
        throw new Error(response.error);
      }
    } catch (error) {
      this.showError('Failed to refresh status: ' + error.message);
    }
  }

  updateStatusDisplay(status) {
    this.elements.serverStatus.textContent = status.system_status || 'Unknown';
    this.elements.currentHost.textContent = status.current_exit_id || 'None';
    this.elements.totalDevices.textContent = status.registered || 0;
    this.elements.onlineDevices.textContent = status.online || 0;
    this.elements.proxyDevices.textContent = status.can_proxy || 0;
  }

  async toggleProxy() {
    try {
      this.showLoading();
      
      const response = await this.sendMessage({ action: 'toggleProxy' });
      
      if (response.success) {
        this.updateConnectionStatus(true, response.enabled);
      } else {
        throw new Error(response.error);
      }
    } catch (error) {
      this.showError('Failed to toggle proxy: ' + error.message);
      // Reset toggle state
      this.elements.proxyToggle.checked = !this.elements.proxyToggle.checked;
    } finally {
      this.hideLoading();
    }
  }

  async saveSettings() {
    try {
      const apiUrl = this.elements.apiUrl.value.trim();
      
      if (!apiUrl) {
        this.showError('API URL is required');
        return;
      }

      this.showLoading();

      const response = await this.sendMessage({
        action: 'updateSettings',
        settings: {
          apiBaseUrl: apiUrl
        }
      });

      if (response.success) {
        this.showSuccess('Settings saved successfully');
        // Refresh status after settings change
        await this.refreshStatus();
      } else {
        throw new Error(response.error);
      }
    } catch (error) {
      this.showError('Failed to save settings: ' + error.message);
    } finally {
      this.hideLoading();
    }
  }

  async reconnect() {
    try {
      this.showLoading();
      
      // The background script will handle reconnection
      await this.refreshStatus();
      
    } catch (error) {
      this.showError('Failed to reconnect: ' + error.message);
    } finally {
      this.hideLoading();
    }
  }

  handleMessage(message) {
    switch (message.type) {
      case 'notification':
        this.handleNotification(message.notificationType, message.data);
        break;
    }
  }

  handleNotification(type, data) {
    switch (type) {
      case 'connected':
        this.updateConnectionStatus(true, false);
        this.showSuccess('Connected to proxy server');
        break;
        
      case 'error':
        this.showError(data);
        break;
        
      case 'proxyToggled':
        this.updateConnectionStatus(true, data.enabled);
        break;
    }
  }

  showLoading() {
    this.isLoading = true;
    this.elements.loadingOverlay.style.display = 'flex';
  }

  hideLoading() {
    this.isLoading = false;
    this.elements.loadingOverlay.style.display = 'none';
  }

  showError(message) {
    this.elements.errorText.textContent = message;
    this.elements.errorMessage.style.display = 'flex';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      this.hideError();
    }, 5000);
  }

  showSuccess(message) {
    // For now, just log success messages
    // You could add a success notification system here
    console.log('Success:', message);
  }

  hideError() {
    this.elements.errorMessage.style.display = 'none';
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new PopupController();
});
